self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e9dcccce022f84aa1a3519d3a2cb71c8",
    "url": "./editor.worker.js"
  },
  {
    "revision": "1bc955240984fa2ed440defe49c5d42b",
    "url": "./index.html"
  },
  {
    "revision": "26129570ad087dcf35a1",
    "url": "./static/css/2.1fbee50d.chunk.css"
  },
  {
    "revision": "18d0f7efe07ca4404dee",
    "url": "./static/css/main.d74e019f.chunk.css"
  },
  {
    "revision": "26129570ad087dcf35a1",
    "url": "./static/js/2.e5ce5336.chunk.js"
  },
  {
    "revision": "300a0a01a49a6ce568c9b658dbd7888d",
    "url": "./static/js/2.e5ce5336.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cfaae6e459fe3abb5b78",
    "url": "./static/js/3.5cbec1b6.chunk.js"
  },
  {
    "revision": "18d0f7efe07ca4404dee",
    "url": "./static/js/main.e1c1bc6e.chunk.js"
  },
  {
    "revision": "27428602a209f6b116b0",
    "url": "./static/js/runtime-main.3d88a4ee.js"
  },
  {
    "revision": "a609dc0f334a7d4e64205247c4e8b97c",
    "url": "./static/media/codicon.a609dc0f.ttf"
  }
]);