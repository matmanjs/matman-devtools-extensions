self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e9dcccce022f84aa1a3519d3a2cb71c8",
    "url": "./editor.worker.js"
  },
  {
    "revision": "a0cc54120f1ed59857310909fd319998",
    "url": "./index.html"
  },
  {
    "revision": "73a2b9598bf2c8dd5df4",
    "url": "./static/css/2.46da9dc3.chunk.css"
  },
  {
    "revision": "41a62cee37fca3bff1b1",
    "url": "./static/css/main.be3541cd.chunk.css"
  },
  {
    "revision": "73a2b9598bf2c8dd5df4",
    "url": "./static/js/2.20352ba6.chunk.js"
  },
  {
    "revision": "300a0a01a49a6ce568c9b658dbd7888d",
    "url": "./static/js/2.20352ba6.chunk.js.LICENSE.txt"
  },
  {
    "revision": "15135d43cd9c67db6c7c",
    "url": "./static/js/3.662c1af0.chunk.js"
  },
  {
    "revision": "41a62cee37fca3bff1b1",
    "url": "./static/js/main.c19a77ed.chunk.js"
  },
  {
    "revision": "2f91bba1c18365695fc5",
    "url": "./static/js/runtime-main.8aea9a1f.js"
  },
  {
    "revision": "a609dc0f334a7d4e64205247c4e8b97c",
    "url": "./static/media/codicon.a609dc0f.ttf"
  }
]);