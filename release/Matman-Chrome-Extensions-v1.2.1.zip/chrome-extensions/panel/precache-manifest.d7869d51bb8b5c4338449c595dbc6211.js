self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e9dcccce022f84aa1a3519d3a2cb71c8",
    "url": "./editor.worker.js"
  },
  {
    "revision": "dfa77b2d1b8719ada90ecb931fb0b083",
    "url": "./index.html"
  },
  {
    "revision": "56d39c3392445af31ef8",
    "url": "./static/css/2.865a99ec.chunk.css"
  },
  {
    "revision": "82cd1a2418f44e65106d",
    "url": "./static/css/main.c9d96b18.chunk.css"
  },
  {
    "revision": "56d39c3392445af31ef8",
    "url": "./static/js/2.dc0dcc3d.chunk.js"
  },
  {
    "revision": "300a0a01a49a6ce568c9b658dbd7888d",
    "url": "./static/js/2.dc0dcc3d.chunk.js.LICENSE.txt"
  },
  {
    "revision": "6eb45d43ad4c10387a55",
    "url": "./static/js/3.a425b17d.chunk.js"
  },
  {
    "revision": "82cd1a2418f44e65106d",
    "url": "./static/js/main.6b2a298a.chunk.js"
  },
  {
    "revision": "eb65e36ca148fe1c6b49",
    "url": "./static/js/runtime-main.ea6238c6.js"
  },
  {
    "revision": "a609dc0f334a7d4e64205247c4e8b97c",
    "url": "./static/media/codicon.a609dc0f.ttf"
  }
]);